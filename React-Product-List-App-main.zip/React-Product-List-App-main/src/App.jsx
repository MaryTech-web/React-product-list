
import ProductList from './Components/ProductList'

function App() {

  return (
    <div>
      <ProductList />
    </div>
  )
}

export default App
